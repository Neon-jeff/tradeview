// Algorithms
// 1. fetch coin symbol, icon and user balance from server
// update a select html element with appropraite option values showing the data from the server

// let form = document.querySelector("form");

// let formData = new FormData(form);

// form.addEventListener("submit", async (e) => {
//   e.preventDefault();
//   for (let key in formData.entries()) {
//     console.log(key);
//   }
// });
